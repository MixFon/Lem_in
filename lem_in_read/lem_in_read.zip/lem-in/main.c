/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: eskeleto <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/05/23 16:07:57 by eskeleto          #+#    #+#             */
/*   Updated: 2019/05/23 16:08:48 by eskeleto         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "lem_in.h"

void	ft_check_linking(t_lem *lem, t_vertex **vertex)
{
	t_vertex	*tmp;

	tmp = *vertex;
	while (tmp != NULL)
	{
		if (tmp->mark_green == 0)
		{
			ft_free_lem(lem);
			ft_free_vertex(vertex);
			ft_error();
		}
		tmp = tmp->next;
	}
}

void	ft_check_graph(t_lem *lem)
{
	t_vertex	*vertex;

	if (lem->start.name_room == NULL || lem->end.name_room == NULL)
	{
		ft_free_lem(lem);
		ft_error();
	}
	vertex = ft_init_graph(lem);
	ft_depth_first_search(lem, &vertex);
	ft_check_linking(lem, &vertex);
	ft_print_vertex(vertex);
	ft_free_vertex(&vertex);
}

int		main(void)
{
	t_lem	lem;

	lem = ft_get_lem();
	ft_check_graph(&lem);
	ft_print_lem(lem);
	ft_free_lem(&lem);
	return (0);
}
